
library(stringr)
source("R/sparql_function_jpr.R")
source("R/query_builder_object.R")
#### TRIPLESTORE-DATA ####
prefix_list<-list(generalPrefix = data.frame(prefix= c("rdfs", "rdf",   "owl", "xml","xsd"),
                              uri= c("http://www.w3.org/2000/01/rdf-schema#", "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
                                     "http://www.w3.org/2002/07/owl#","http://www.w3.org/XML/1998/namespace",
                                     "http://www.w3.org/2001/XMLSchema#")),
             epitrackPrefix = data.frame(prefix= c("btl2", "cepi", "hepi", "depi" ),
                                   uri= c("http://purl.org/biotop/btl2.owl#",  "http://www.chu-lyon.fr/epitrack/epitrack-core#",
                                                NA, NA))
)

graph_list<-list(cepi='http://www.epitrack/core-ontology/',
            hepi='',
            depi='')
sparql_engine<-"http://localhost:8890/sparql/"



query_builder<-new(Class = "SPARQL_query_builder", prefix=rbind(prefix_list[["generalPrefix"]],
                                                                prefix_list[["epitrackPrefix"]][1:2,]),
                   graph=list(graph_list[["cepi"]]),method='SELECT')
query_builder<-addConstraint(query_builder,subj="?s",obj="cepi:CEPI0000000021", pred="rdfs:subClassOf")
query_builder<-addConstraint(query_builder,subj="?s",obj="?label", pred="rdfs:label")
query_builder<-addConstraint(query_builder,subj="?s",obj="?ATC_CODE", pred="cepi:ATC_code")

query_builder_param<-new(Class = "SPARQL_query_builder", prefix=rbind(prefix_list[["generalPrefix"]],
                                                                prefix_list[["epitrackPrefix"]][1:2,]),
                   graph=list(graph_list[["cepi"]]),method='SELECT')
query_builder_param<-addConstraint(query_builder_param,subj="?s",obj="<<PARAM_ATC>>", pred="rdfs:subClassOf")
query_builder_param<-addConstraint(query_builder_param,subj="?s",obj="?label", pred="rdfs:label")
query_builder_param<-addConstraint(query_builder_param,subj="?s",obj="?ATC_CODE", pred="cepi:ATC_code")


query_builder_all<-new(Class = "SPARQL_query_builder", prefix=rbind(prefix_list[["generalPrefix"]],
                                                                    prefix_list[["epitrackPrefix"]][1:2,]),
                       graph=list(graph_list[["cepi"]]),method='SELECT')
constraintFrame<-data.frame(subj=c("?s","?s","?s"),pred=c("rdfs:subClassOf","rdfs:label","cepi:ATC_code"),
                            obj=c("cepi:CEPI0000000021","?label", "?ATC_CODE"))
query_builder_all<-addConstraintFrame(query_builder_all,data = constraintFrame,keep=NA)


query_builder_all_param<-new(Class = "SPARQL_query_builder", prefix=rbind(prefix_list[["generalPrefix"]],
                                                                          prefix_list[["epitrackPrefix"]][1:2,]),
                             graph=list(graph_list[["cepi"]]),method='SELECT')
constraintFrame_param<-data.frame(subj=c("?s","?s","?s"),pred=c("rdfs:subClassOf","rdfs:label","cepi:ATC_code"),
                            obj=c("<<PARAM_ATC>>","?label", "?ATC_CODE"))
query_builder_all_param<-addConstraintFrame(query_builder_all_param,data = constraintFrame_param,keep=NA)


parameter_data<-data.frame(parameter = character(0), value=character(0))
parameter_data<-rbind(parameter_data,
                      data.frame(parameter="<<PARAM_ATC>>", value = "cepi:CEPI0000000021"))

build(query_builder_all_param,param_data = parameter_data)
queryString<-build(query_builder_all)

sparqlGet(sparql_engine, queryString, type = "csv")

sparqlGet(sparql_engine, sparql = queryString)
