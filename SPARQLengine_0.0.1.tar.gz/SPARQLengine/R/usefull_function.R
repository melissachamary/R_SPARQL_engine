normalize<-function(string){
  return(trimws(toupper(string)))
}
